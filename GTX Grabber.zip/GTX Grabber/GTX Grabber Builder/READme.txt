Python 3.10 or above must be installed!
Internet connection must be available!
Disable your antivirus/defender as it might delete some important files!

Run "Builder.bat"